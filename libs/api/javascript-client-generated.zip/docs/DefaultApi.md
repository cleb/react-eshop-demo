# ReactDemoEshop.DefaultApi

All URIs are relative to *https://virtserver.swaggerhub.com/jjjudas/react-eshop-demo/1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productsGet**](DefaultApi.md#productsGet) | **GET** /products | Get all products


<a name="productsGet"></a>
# **productsGet**
> [Product] productsGet()

Get all products

### Example
```javascript
var ReactDemoEshop = require('react_demo_eshop');

var apiInstance = new ReactDemoEshop.DefaultApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productsGet(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**[Product]**](Product.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

